<?php
$conn = mysqli_connect('localhost','root','','slip_pass');
date_default_timezone_set('Asia/Kolkata');

?>