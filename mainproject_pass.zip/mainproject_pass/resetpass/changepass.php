<?php include '../config/config.php'; 
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <title>Document</title>
</head>
<body style="padding-left:0">

<header class="header">
        <section class="flex" style="justify-content:center;">
        <h3 class="logo">A.P Shah Institute of Technology</h3>
        </section>
</header>
<?php
       if(isset($_SESSION['message'])){
        echo '<div class="message-box">
        <span>'.$_SESSION['message'].'</span>
        <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
     </div>';
        unset($_SESSION['message']);
    }
        ?>
<div style="margin-top:100px;" class="emp-add">
    <form action="changepasscode.php" method="post">
        
        <!-- Page Title for Password Reset -->
        <h2>Reset password</h2>

        <!-- Hidden Field to Store Password Reset Token -->
        <input type="hidden" value="<?php if(isset($_GET['id'])){echo $_GET['token'];} ?>" name="pass_token">
        
        <!-- Input field for Employee ID, with pre-filled value if provided in the URL -->
        <div class="form-group">
            <input class="box" placeholder="Enter your id" value="<?php if(isset($_GET['id'])){echo $_GET['id'];} ?>" type="number" id="id" name="id" required>
        </div>
       
        <!-- Input field for New Password -->
        <div class="form-group">
            <input type="password" class="box" id="text" name="pass" placeholder="Enter your new password" required>
        </div>

        <!-- Input field to Confirm New Password -->
        <div class="form-group">
            <input type="password" class="box" id="text" name="cpass" placeholder="Confirm your new password" required>
        </div>

        <!-- Reset Password Button -->
        <button class="submit" name="reset_submit" type="submit">Reset</button>

    </form>
</div>


    <?php mysqli_close($conn); ?>
</body>
</html>