-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2023 at 04:33 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `slip_pass`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountant`
--

CREATE TABLE `accountant` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accountant`
--

INSERT INTO `accountant` (`id`, `name`, `designation`, `password`) VALUES
(1, 'jayesh', 'accountant', '');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`, `designation`) VALUES
(1, 'admin', '', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `employee_details`
--

CREATE TABLE `employee_details` (
  `emp_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gmail` varchar(255) NOT NULL,
  `phone_no` varchar(11) NOT NULL,
  `pan_no` varchar(10) NOT NULL,
  `pf_no` varchar(25) NOT NULL,
  `uan_no` varchar(25) NOT NULL,
  `bank_acc` varchar(25) NOT NULL,
  `department` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `joining_date` date NOT NULL,
  `leaving_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee_details`
--

INSERT INTO `employee_details` (`emp_id`, `name`, `gmail`, `phone_no`, `pan_no`, `pf_no`, `uan_no`, `bank_acc`, `department`, `designation`, `role`, `joining_date`, `leaving_date`) VALUES
(2, 'Jayesh Deshmukh', 'jayesh@gmail.com', '1234567890', 'DEF1234567', 'DEF2020202020202020202', '223344556677', '222222222222222', 'COMP', 'Teaching', 'Employee', '2019-10-03', NULL),
(3, 'Harshal Aponkar', 'harshalaponkar@gmail.com', '5214569870', 'GHI1234567', 'GHI3030303030303030303', '334455667788', '333333333333333', 'COMP', 'Teaching', 'Accountant', '2019-10-04', '0000-00-00'),
(5252, 'SA', 'hackur69@gmail.com', '9525241245', 'HIC8621925', '1111', '822965314565', '11111', 'Comps', 'Teaching', 'SA', '2023-11-02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `resetpass`
--

CREATE TABLE `resetpass` (
  `id` int(255) NOT NULL,
  `emp_id` int(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reset_token_hash` varchar(255) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resetpass`
--

INSERT INTO `resetpass` (`id`, `emp_id`, `password`, `reset_token_hash`, `reset_token_expires_at`) VALUES
(1, 5252, 'bfe66064950d13c8cca6086b1e107571ff405e45', '', '0000-00-00 00:00:00'),
(10, 2, 'f0d2580221200ed5a0a552890386f4d2431f765d', '6988692ebcb3da97318a6c22c431739ec4b309f4', '2023-11-01 08:51:00'),
(11, 3, 'ab54d425fa8ac654e8cdf0307eebcc33ea46d08e', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `id` int(11) NOT NULL,
  `emp_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `basic_salary` int(100) NOT NULL,
  `agp` int(100) NOT NULL,
  `days_worked` int(100) NOT NULL,
  `actual_basic` int(100) NOT NULL,
  `actual_agp` int(100) NOT NULL,
  `basic_add_agp` int(100) NOT NULL,
  `da` int(100) NOT NULL,
  `hra` int(100) NOT NULL,
  `cla` int(100) NOT NULL,
  `ta` int(100) NOT NULL,
  `exam_rem` int(100) NOT NULL,
  `spl_pay` int(100) NOT NULL,
  `gross` int(100) NOT NULL,
  `pf` int(100) NOT NULL,
  `pt` int(100) NOT NULL,
  `i_tax` int(100) NOT NULL,
  `add_ded` int(100) NOT NULL,
  `net_salary` int(100) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`id`, `emp_id`, `name`, `designation`, `basic_salary`, `agp`, `days_worked`, `actual_basic`, `actual_agp`, `basic_add_agp`, `da`, `hra`, `cla`, `ta`, `exam_rem`, `spl_pay`, `gross`, `pf`, `pt`, `i_tax`, `add_ded`, `net_salary`, `date`) VALUES
(184, 2, 'Jayesh', 'Professor', 9001, 1001, 28, 500, 1250, 521, 250, 2100, 220, 52, 255, 2552, 25000, 0, 0, 0, 0, 22000, '2023-11-01'),
(185, 3, 'Harshal', 'Professor', 3001, 1001, 28, 500, 1250, 520, 250, 2100, 220, 52, 255, 2552, 25000, 0, 0, 0, 0, 22000, '2023-11-01'),
(186, 2, 'Jayesh Deshmukh', 'Teaching', 1000, 6000, 29, 935, 5613, 6548, 10739, 1964, 300, 2400, 0, 0, 21951, 1800, 200, 1620, 0, 18331, '2023-10-01'),
(187, 3, 'Harshal Aponkar', 'Teaching', 1000, 6000, 29, 935, 5613, 6548, 10739, 1964, 300, 2400, 0, 0, 21951, 1800, 200, 1620, 0, 5, '2023-10-01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accountant`
--
ALTER TABLE `accountant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_details`
--
ALTER TABLE `employee_details`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `resetpass`
--
ALTER TABLE `resetpass`
  ADD PRIMARY KEY (`id`),
  ADD KEY `emp_id` (`emp_id`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accountant`
--
ALTER TABLE `accountant`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `resetpass`
--
ALTER TABLE `resetpass`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=188;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
