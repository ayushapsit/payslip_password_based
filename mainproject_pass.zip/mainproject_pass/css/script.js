let navbar = document.querySelector('.header .flex .navbar');
document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
}
let date = document.querySelector('.dateselection');
document.querySelector('#picker').onclick =()=>{
    date.classList.toggle('active');
    document.querySelector('#content').innerHTML = "Jayesh";
}

function goBack() {
    window.history.back();
}
window.onscroll = () =>{
    navbar.classList.remove('active');
 }

