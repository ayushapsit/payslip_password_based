<!-- 
    ********************
    
    THIS PAGE HERE CONTAINS THE PROCEDURE FOR CHANGING THE PASSWORD IF EMPLOYEE HAS LOGGED ONTO THE SYSTEM FOR FIRST TIME

    ********************
  -->
  <?php include 'config/config.php'; 
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <title>Change Password</title>
</head>
<body style="padding-left: 0">
<header class="header">
        <section class="flex" style="justify-content:center;">
        <h3 class="logo">A.P Shah Institute of Technology</h3>
        </section>
    </header>
<?php
       if(isset($_SESSION['message'])){
        echo '<div class="message-box">
        <span>'.$_SESSION['message'].'</span>
        <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
     </div>';
        unset($_SESSION['message']);
    }
        ?>
<?php
if(isset($_POST['change_pass'])){
    $id = mysqli_real_escape_string($conn,$_POST['id']);
    $pass = mysqli_real_escape_string($conn,$_POST['pass']);
    $cpass = mysqli_real_escape_string($conn,$_POST['cpass']);
    $cpass = sha1($cpass);
    $pass= sha1($pass);
    // echo $id.' '.$pass.' '.$cpass.' '.$pass;
    // CODE TO CHECK IF BOTH PASSWORD AND CONFIRM PASSWORD MATCHES
    // IF IT DOES CHANGE THE PASSWORD
    // $_SESSION['ids'] THIS SESSION VARIABLE IS SET ONLY TO CHECK FOR NEW PASSWORD 
    if($pass==$cpass && $id==$_SESSION['ids']){
        $update = "UPDATE resetpass SET password ='$pass' WHERE emp_id = '{$_SESSION['ids']}'";
        $result = mysqli_query($conn,$update) or die('Connection Failed');
        $_SESSION['message'] = "Password Changed Please login";
        header('location:index.php'); 
       }else{
        $_SESSION['message']="Password does not match or id does not exist";
       }
}
?>

<!-- FORM TO ENTER THE DETAILS STARTS -->
<section class="emp-add">
    <form style="margin-top: 100px;" action="" method="post">
        
    <h2>Change Password</h2>
    <input type="text" class="box" id="name" name="id" placeholder="Enter Id" required>
    <input type="password" id="cpass" class="box"  name="pass"  placeholder="Enter New Password"  required>
    <input type="password" id="pass" class="box" name="cpass" placeholder="Confirm your password"required>
    <input type="submit" class="submit" name="change_pass" value="Change">
</form>
</section>
<!-- FORM TO ENTER THE DETAILS ENDS -->


<?php mysqli_close($conn); ?>
</body>
</html>