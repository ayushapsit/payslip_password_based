<!-- 
    ********************
    
    THIS PAGE HERE CONTAINS ALL THE LOGIN PROCEDURE

    ********************
  -->

<?php include 'config/config.php'; 
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <title>Login Page</title>
</head>
<body style="padding-left: 0">
<!-- CODE FOR HEADER  -->
<header class="header">
    <section class="flex" style="justify-content:center;">
        <h3 class="logo">A.P Shah Institute of Technology</h3>
    </section>
</header>
<!-- CODE FOR HEADER  -->

    <!-- CODE TO DISPLAY ANY MESSAGE STARTS -->
    <?php
if(isset($_SESSION['message'])){
    echo '<div class="message-box">
    <span>'.$_SESSION['message'].'</span>
    <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
    </div>';
    unset($_SESSION['message']);
}
        ?>
<!-- CODE TO DISPLAY ANY MESSAGE ENDS -->
 
<div style="margin-top:100px;" class="emp-add">
   <!-- FORM TO ENTER LOGIN DETAILS STARTS -->
   <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
    <!-- Page Title -->
    <h2 style="margin-bottom:10px; ">APSIT PayEngine</h2>
    <!-- Login Prompt -->
    <p >Please login to continue</p>
    
    <!-- Input field for Employee ID -->
    <div class="form-group">
        <input class="box" placeholder="Enter your id" type="number" id="id" name="id" required>
    </div>
    
    <!-- Input field for Password -->
    <div class="form-group">
        <input type="password" class="box" id="password" name="password" placeholder="Enter your password" required>
    </div>
    
    <!-- Login Button -->
    <button class="submit" name="log_submit" type="submit">Login</button>
    
    <!-- Forgot Password Link -->
    <p class="forget" >Forgot password? <a href="resetpass/resetpass.php">Click to reset!</a></p>
    </form>
    <!-- FORM TO ENTER LOGIN DETAILS ENDS -->
</div>



    <!-- Login Code -->
    <?php 
    if (isset($_POST['log_submit'])) {
        $id = mysqli_real_escape_string($conn,$_POST['id']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $password = sha1($password); //sha1 is used to encrypt the code


        $check = "SELECT * FROM resetpass WHERE emp_id = {$id}";
        $result = mysqli_query($conn, $check);
    
        if (mysqli_num_rows($result) > 0) {
            // LOGIC TO CHECK WHETHER EMPLOYEE IS LOGIN FOR THE FIRST TIME STARTS
            $row = mysqli_fetch_assoc($result);
            if ($row['password'] == sha1($id . "@Apsit") && $row['password'] == $password) {
                session_start();
                $_SESSION['ids'] = $id;
                $_SESSION['message'] = "Please Change the default password";
                header('location: changepassword.php');
                // LOGIC TO CHECK WHETHER EMPLOYEE IS LOGIN FOR THE FIRST TIME ENDS
            } else {
                // CODE TO LOGIN FOR OLD EMPLOYEE STARTS
                $query = "SELECT * FROM employee_details as e JOIN resetpass as rp ON e.emp_id = rp.emp_id WHERE e.emp_id = {$id} AND rp.password = '{$password}' ";
                $result = mysqli_query($conn, $query) or die("QUERY FAILED");
    
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        // SET THE SESSION VARIABLES TO USE ACCROSS THE SYSTEM
                        $_SESSION['id'] = $row['emp_id'];
                        $_SESSION['name'] = $row['name'];
                        $_SESSION['designation'] = $row['designation'];
                        // GET CURRENT TIME AFTER SUCCESSFUL LOGIN 
                        $_SESSION['last_activity'] = time();
    
                        // Determine the role and set the session type accordingly
                        // if ($row['role'] == 'HR') {
                        //     $_SESSION['type'] = 'HR';
                        //     header('location: admin/admin.php');
                        // } 
                        if ($row['role'] == 'Accountant') {
                            $_SESSION['type'] = 'accountant';
                            header('location: accountant/upload.php');
                        } elseif ($row['role'] == 'Employee') {
                            $_SESSION['type'] = 'employee';
                            header('location: employee/currentmonth.php');
                        }elseif ($row['role'] == 'SA') {
                            $_SESSION['type'] = 'SA';
                            header('location: SA/role.php');
                        } else {
                            echo '<script>alert("Invalid Role or your id doesnt exist");</script>';
                        }
                    }
                } else {
                    echo '<script>alert("Id or password not matched");</script>';
                }
                // CODE TO LOGIN FOR OLD EMPLOYEE STARTS
            }
        } else {
            echo '<script>alert("Id or password not matched");</script>';
        }
    }
    mysqli_close($conn);
    ?>

<script>
    // Check if there's a message in the URL (added during automatic logout)
    const urlParams = new URLSearchParams(window.location.search);
    const message = urlParams.get('message');

    if (message) {
        // Display an alert with the message
        alert(message);
    }
</script>
</body>
</html>
